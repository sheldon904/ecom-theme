<?php
/**
 * Template Name: Checkout Template
 * Description: A custom checkout page template for Lambo Merch using WooCommerce hooks.
 */

defined( 'ABSPATH' ) || exit;

// Make sure WC is loaded and we're on the checkout page
if (!function_exists('WC') || !WC()->cart->needs_payment()) {
    wp_redirect(wc_get_cart_url());
    exit;
}

// Make sure Stripe and other payment scripts are properly loaded
WC()->payment_gateways()->payment_scripts();

// Remove any notices that might be visible
wc_clear_notices();

get_header();
?>

<main id="primary" class="site-main custom-checkout-page">
  <div class="container">
    <h2 class="checkout-heading">Checkout</h2>
    
    <div class="checkout-container">
      <!-- Returning customer info box -->
      <div class="checkout-info-box">
        <p>Returning customer? <a href="#" class="checkout-link" id="login-trigger">Click here to login</a></p>
      </div>
      
      <!-- Login form (hidden by default) -->
      <div id="login-form" style="display: none; margin-bottom: 15px;">
        <?php 
        // Display the WooCommerce login form
        woocommerce_login_form(array(
          'message' => '',
          'redirect' => wc_get_checkout_url(),
          'hidden' => false,
        )); 
        ?>
      </div>
      
      <!-- Coupon info box -->
      <div class="checkout-info-box">
        <p>Have a coupon? <a href="#" class="checkout-link" id="coupon-trigger">Click here to enter your code</a></p>
      </div>
      
      <!-- Coupon form (hidden by default) -->
      <div id="coupon-form" class="coupon-form" style="display: none;">
        <form class="checkout_coupon woocommerce-form-coupon" method="post">
          <p><?php esc_html_e( 'If you have a coupon code, please apply it below.', 'woocommerce' ); ?></p>
          
          <div class="coupon-form-row">
            <input type="text" name="coupon_code" class="input-text" placeholder="<?php esc_attr_e( 'Coupon code', 'woocommerce' ); ?>" id="coupon_code" value="" />
            <button type="submit" class="button" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?>"><?php esc_html_e( 'Apply', 'woocommerce' ); ?></button>
          </div>
          <?php do_action( 'woocommerce_cart_coupon' ); ?>
        </form>
      </div>
      
      <!-- Checkout form start -->
      <form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">
        
        <?php if ( $checkout = WC()->checkout() ) : ?>
        
          <?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>
          
          <div class="customer-details-section">
            <!-- Billing and shipping details header row -->
            <div class="details-header">
              <h2 class="checkout-heading">Billing Details</h2>
              <div class="ship-to-different-wrapper">
                <label for="ship-to-different-address-checkbox" class="checkbox">
                  <input id="ship-to-different-address-checkbox" class="woocommerce-form__input-checkbox input-checkbox" <?php checked( apply_filters( 'woocommerce_ship_to_different_address_checked', 'shipping' === get_option( 'woocommerce_ship_to_destination' ) ? 1 : 0 ), 1 ); ?> type="checkbox" name="ship_to_different_address" value="1" />
                  <span>Ship to a different address?</span>
                </label>
              </div>
            </div>
            
            <div class="row-columns">
              <!-- Billing column -->
              <div class="billing-column">
                <?php do_action( 'woocommerce_checkout_billing' ); ?>
                
                <!-- Create account checkbox -->
                <?php if ( ! is_user_logged_in() && $checkout->is_registration_enabled() ) : ?>
                  <div class="create-account-checkbox">
                    <p class="form-row">
                      <label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
                        <input class="woocommerce-form__input-checkbox input-checkbox" id="createaccount" <?php checked( ( true === $checkout->get_value( 'createaccount' ) || ( true === apply_filters( 'woocommerce_create_account_default_checked', false ) ) ), true ); ?> type="checkbox" name="createaccount" value="1" /> <span><?php esc_html_e( 'Create an account?', 'woocommerce' ); ?></span>
                      </label>
                    </p>
                  </div>
                <?php endif; ?>
              </div>
              
              <!-- Shipping column (conditionally shown) -->
              <div class="shipping-column" style="<?php echo ( empty( $_POST['ship_to_different_address'] ) && empty( $checkout->get_value( 'ship_to_different_address' ) ) ) ? 'display:none;' : ''; ?>">
                <?php do_action( 'woocommerce_checkout_shipping' ); ?>
                
                <!-- Order notes -->
                <div class="order-notes">
                  <label for="order_comments"><?php esc_html_e( 'Order notes', 'woocommerce' ); ?></label>
                  <textarea name="order_comments" id="order_comments" placeholder="<?php esc_attr_e( 'Notes about your order, e.g. special notes for delivery.', 'woocommerce' ); ?>" rows="4"></textarea>
                </div>
              </div>
            </div>
          </div>
          
          <?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>
          
        <?php endif; ?>
        
        <!-- Order Summary Section -->
        <h2 class="checkout-heading">Your Order</h2>
        
        <div class="order-review-container">
          <?php do_action( 'woocommerce_checkout_before_order_review' ); ?>
          
          <div id="order_review" class="woocommerce-checkout-review-order">
            <?php do_action( 'woocommerce_checkout_order_review' ); ?>
          </div>
          
          <?php do_action( 'woocommerce_checkout_after_order_review' ); ?>
        </div>
        
      </form>
    </div>
  </div>
</main>

<style>
/* Main checkout styling */
.custom-checkout-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
  color: #ffffff;
}

.container {
  width: 100%;
}

/* Checkout heading */
.checkout-heading {
  color: #ff0000;
  font-style: italic;
  margin-bottom: 1.5rem;
  font-size: 2rem;
  text-align: left;
}

/* Info boxes for returning customer and coupon */
.checkout-info-box {
  background-color: #333333;
  padding: 15px;
  margin-bottom: 15px;
  width: 100%;
  color: #ffffff;
}

/* Styles for links in info boxes */
.checkout-link {
  color: #ffffff;
  text-decoration: underline;
  cursor: pointer;
}

/* Coupon form styling */
.coupon-form {
  background-color: #222222;
  padding: 15px;
  margin-bottom: 15px;
  width: 100%;
}

.coupon-form p {
  color: #ffffff;
  margin-bottom: 10px;
}

.coupon-form-row {
  display: flex;
  gap: 10px;
}

.coupon-form input[type="text"] {
  flex: 1;
  background-color: #333333;
  border: 1px solid #444444;
  color: #ffffff;
  padding: 10px;
}

.coupon-form button {
  width: 100px;
  background-color: #ff0000;
  color: #ffffff;
  border: none;
  padding: 10px;
  cursor: pointer;
}

/* Login form styling */
.woocommerce-form-login {
  background-color: #222222;
  padding: 15px;
  margin-bottom: 15px;
  color: #ffffff;
}

.woocommerce-form-login input[type="text"],
.woocommerce-form-login input[type="password"] {
  background-color: #333333;
  border: 1px solid #444444;
  color: #ffffff;
  padding: 10px;
  width: 100%;
  margin-bottom: 10px;
}

.woocommerce-form-login button {
  background-color: #ff0000;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  cursor: pointer;
}

/* Customer details section */
.customer-details-section {
  margin-top: 30px;
  margin-bottom: 20px;
}

/* Header row with billing title and shipping checkbox */
.details-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.details-header h2 {
  margin: 0;
}

.ship-to-different-wrapper {
  display: flex;
  align-items: center;
  color: #ffffff;
}

.ship-to-different-wrapper input[type="checkbox"] {
  margin-right: 8px;
}

/* Two-column layout for billing and shipping */
.row-columns {
  display: flex;
  flex-wrap: wrap;
  gap: 30px;
}

.billing-column,
.shipping-column {
  flex: 1;
  min-width: 300px;
}

/* Form field styling */
.woocommerce-billing-fields__field-wrapper,
.woocommerce-shipping-fields__field-wrapper,
.woocommerce-account-fields,
.woocommerce-additional-fields {
  margin-bottom: 20px;
}

.woocommerce-billing-fields h3,
.woocommerce-shipping-fields h3,
.woocommerce-additional-fields h3 {
  /* Hide default WooCommerce headings */
  display: none;
}

/* Style all checkout form fields */
.woocommerce-checkout .form-row {
  margin-bottom: 15px;
}

.woocommerce-checkout .form-row label {
  display: none; /* Hide labels to match the original design */
}

.woocommerce-checkout .form-row .input-text,
.woocommerce-checkout .form-row select {
  background-color: #333333;
  border: 1px solid #444444;
  color: #ffffff;
  padding: 12px;
  width: 100%;
}

.woocommerce-checkout .form-row textarea {
  background-color: #333333;
  border: 1px solid #444444;
  color: #ffffff;
  padding: 12px;
  width: 100%;
  height: 100px;
}

/* Add placeholders for all fields */
.woocommerce-checkout #billing_first_name_field input::placeholder,
.woocommerce-checkout #shipping_first_name_field input::placeholder {
  content: "First name *";
}

.woocommerce-checkout #billing_last_name_field input::placeholder,
.woocommerce-checkout #shipping_last_name_field input::placeholder {
  content: "Last name *";
}

/* Create account checkbox */
.create-account-checkbox {
  margin-top: 20px;
}

.create-account-checkbox label {
  display: flex !important;
  align-items: center;
  color: #ffffff;
}

.create-account-checkbox input[type="checkbox"] {
  margin-right: 8px;
}

/* Order notes */
.order-notes {
  margin-top: 20px;
}

.order-notes label {
  display: block;
  color: #ffffff;
  margin-bottom: 8px;
}

/* Order Review */
.order-review-container {
  margin-top: 30px;
}

.woocommerce-checkout-review-order-table {
  width: 100%;
  background-color: #222222;
  color: #ffffff;
  border-collapse: collapse;
}

.woocommerce-checkout-review-order-table th,
.woocommerce-checkout-review-order-table td {
  padding: 15px;
  text-align: left;
  border-bottom: 1px solid #333333;
}

.woocommerce-checkout-review-order-table .product-name {
  display: flex;
  align-items: center;
}

.woocommerce-checkout-review-order-table .product-name img {
  width: 60px;
  height: auto;
  margin-right: 15px;
}

.woocommerce-checkout-review-order-table .product-total {
  text-align: right;
}

.woocommerce-checkout-review-order-table .cart-subtotal,
.woocommerce-checkout-review-order-table .order-total {
  font-weight: bold;
}

.woocommerce-checkout-review-order-table .cart-subtotal td,
.woocommerce-checkout-review-order-table .order-total td {
  text-align: right;
}

.woocommerce-checkout-review-order-table .order-total {
  border-top: 2px solid #444444;
}

/* Payment section */
#payment {
  margin-top: 30px;
  background-color: #000000;
  color: #ffffff;
}

#payment .payment_methods {
  list-style: none;
  padding: 0;
  margin: 0;
  border-bottom: 1px solid #333333;
}

#payment .payment_methods li {
  padding: 15px;
  border-bottom: 1px solid #333333;
}

#payment .payment_methods li:last-child {
  border-bottom: none;
}

#payment .payment_methods label {
  display: inline-block;
  margin-left: 8px;
  color: #ffffff;
}

#payment .payment_box {
  padding: 15px;
  background-color: #333333;
  color: #ffffff;
  margin-top: 10px;
}

/* Stripe elements */
.wc-stripe-elements-field,
.wc-stripe-iban-element-field {
  background-color: #333333 !important;
  border: 1px solid #444444 !important;
  padding: 15px !important;
}

/* Payment buttons */
.place-order {
  padding: 20px;
  text-align: right;
}

#place_order {
  background-color: #ff0000;
  color: #ffffff;
  padding: 15px 30px;
  border: none;
  text-transform: uppercase;
  font-weight: bold;
  width: 100%;
  cursor: pointer;
}

/* Express checkout (hide it) */
.woocommerce-checkout .express-checkout-section,
.woocommerce-checkout #express-payment-method,
.wp-block-woocommerce-checkout-express-payment-block,
.wc-block-components-express-payment,
.wc-block-components-express-payment--from-saved-payment-methods,
div[class*="express-payment"],
.express-payment-section,
.wc-stripe-payment-request-wrapper {
  display: none !important;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .details-header {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .ship-to-different-wrapper {
    margin-top: 10px;
  }
  
  .row-columns {
    flex-direction: column;
  }
  
  .billing-column,
  .shipping-column {
    width: 100%;
  }
}
</style>

<script>
jQuery(document).ready(function($) {
  // Toggle login form
  $('#login-trigger').on('click', function(e) {
    e.preventDefault();
    $('#login-form').slideToggle();
  });
  
  // Toggle coupon form
  $('#coupon-trigger').on('click', function(e) {
    e.preventDefault();
    $('#coupon-form').slideToggle(400, function() {
      if ($(this).is(':visible')) {
        $(this).find('input[name="coupon_code"]').focus();
      }
    });
  });
  
  // Toggle shipping column when checkbox is clicked
  $('#ship-to-different-address-checkbox').on('change', function() {
    if ($(this).is(':checked')) {
      $('.shipping-column').slideDown();
    } else {
      $('.shipping-column').slideUp();
    }
  });
  
  // Fix product images in order review
  const fixOrderReviewImages = function() {
    $('.woocommerce-checkout-review-order-table .product-name').each(function() {
      if (!$(this).find('img').length) {
        const productImage = $(this).data('product-image');
        if (productImage) {
          $(this).prepend('<img src="' + productImage + '" alt="Product" />');
        }
      }
    });
  };
  
  // Apply custom styling to Stripe elements when loaded
  const styleStripeElements = function() {
    // Apply styling to payment boxes
    $('.payment_box, .wc-stripe-elements-field').css({
      'background-color': '#333333',
      'color': '#ffffff'
    });
    
    // Style the payment method labels
    $('.payment_method_stripe label').css('color', '#ffffff');
    
    // Style Stripe Elements
    $('.wc-stripe-elements-field, .wc-stripe-iban-element-field').css({
      'background-color': '#333333',
      'border': '1px solid #444444',
      'padding': '15px'
    });
    
    // Hide any express checkout elements that might appear
    $('.wc-stripe-payment-request-wrapper').hide();
  };
  
  // Watch for Stripe elements to be loaded and style them
  const stripeCheckInterval = setInterval(function() {
    if ($('.wc-stripe-elements-field').length > 0) {
      styleStripeElements();
      clearInterval(stripeCheckInterval);
    }
  }, 500);
  
  // Ensure order review updates show images
  $(document.body).on('updated_checkout', function() {
    fixOrderReviewImages();
    styleStripeElements();
  });
  
  // Run initial setup
  fixOrderReviewImages();
  styleStripeElements();
  
  // Placeholder text for fields (this helps match your original design)
  $('#billing_first_name').attr('placeholder', 'First name *');
  $('#billing_last_name').attr('placeholder', 'Last name *');
  $('#billing_company').attr('placeholder', 'Company (optional)');
  $('#billing_address_1').attr('placeholder', 'Street address *');
  $('#billing_address_2').attr('placeholder', 'Apartment, suite, unit, etc. (optional)');
  $('#billing_city').attr('placeholder', 'Town / City *');
  $('#billing_postcode').attr('placeholder', 'ZIP Code *');
  $('#billing_state').attr('placeholder', 'State / Province *');
  $('#billing_email').attr('placeholder', 'Email *');
  $('#billing_phone').attr('placeholder', 'Phone number *');
  
  $('#shipping_first_name').attr('placeholder', 'First name *');
  $('#shipping_last_name').attr('placeholder', 'Last name *');
  $('#shipping_company').attr('placeholder', 'Company (optional)');
  $('#shipping_address_1').attr('placeholder', 'Street address *');
  $('#shipping_address_2').attr('placeholder', 'Apartment, suite, unit, etc. (optional)');
  $('#shipping_city').attr('placeholder', 'Town / City *');
  $('#shipping_postcode').attr('placeholder', 'ZIP Code *');
  $('#shipping_state').attr('placeholder', 'State / Province *');
});
</script>

<?php
get_footer();
?>