<?php
/**
 * The template for displaying the footer
 *
 * @package Lambo_Merch
 */

// Include Mobile_Detect library if not already included
if (!class_exists('Mobile_Detect')) {
    require_once get_template_directory() . '/inc/mobile-detect.php';
}

$detect = new Mobile_Detect;
// Check if user is on a mobile device like an iPhone
$is_mobile = $detect->isMobile() && !$detect->isTablet();
?>

    </div><!-- #content -->

    <footer id="colophon" class="site-footer">
        <div class="footer-widgets">
            <div class="container">
                <?php if ($is_mobile): // Mobile footer layout ?>
                
                <div class="row">
                    <div class="col-12 text-center">
                        <!-- Mobile footer logo at 25% size -->
                        <div class="footer-logo">
                            <a href="<?php echo esc_url(home_url('/')); ?>" class="custom-logo-link" rel="home">
                                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/logo/LM_logo_footer.png" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" class="custom-logo">
                            </a>
                        </div>
                        
                        <!-- Vertically stacked navigation -->
                        <div class="footer-nav text-center">
                            <ul>
                            <center><li><a href="<?php echo esc_url(home_url('/shop')); ?>"><?php esc_html_e('Shop', 'lambo-merch'); ?></a></li></center>
                            <center><li><a href="<?php echo esc_url(home_url('/about')); ?>"><?php esc_html_e('About', 'lambo-merch'); ?></a></li></center>
                            <center><li><a href="<?php echo esc_url(home_url('/contact')); ?>"><?php esc_html_e('Contact', 'lambo-merch'); ?></a></li></center>
                            <center><li><a href="<?php echo esc_url(home_url('/my-account')); ?>"><?php esc_html_e('My Account', 'lambo-merch'); ?></a></li></center>
                            <center><li><a href="/favs-2/"><?php esc_html_e('Favs / Wishlist', 'lambo-merch'); ?></a></li></center>
                            </ul>
                        </div>
                        
                        <!-- Subscribe section -->
                        <div class="subscribe-section">
                            <h3 class="subscribe-title"><?php esc_html_e('SUBSCRIBE FOR DISCOUNTS & DROPS','lambo-merch'); ?></h3>
                                <div class="email-signup">
                                    <?php 
                                        // Embed WPForms form ID 762 without title/description
                                        echo do_shortcode( '[wpforms id="762" title="false" description="false" captcha="false"]' );
                                    ?>
                            </div>
                            
                            <!-- Social icons in a row -->
                            <h3 class="follow-title"><?php esc_html_e('FOLLOW', 'lambo-merch'); ?></h3>
                            <div class="social-icons">
                                <a href="https://www.instagram.com/bavarianrennsport/" target="_blank" class="social-icon facebook-instagram">
                                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/icons/facebook_instagram.png" alt="Facebook/Instagram">
                                </a>
                                <a href="https://www.youtube.com/channel/UC7z8YdJu3WhzR7jli6qTIqQ" target="_blank" class="social-icon youtube">
                                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/icons/youtube.png" alt="YouTube">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php else: // Desktop footer layout ?>
                
                <div class="row">
                    <div class="col-md-4">
                        <div class="footer-content-wrapper">
                            <div class="footer-logo">
                                <a href="<?php echo esc_url(home_url('/')); ?>" class="custom-logo-link" rel="home">
                                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/logo/LM_logo_footer.png" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" class="custom-logo">
                                </a>
                            </div>
                            
                            <div class="footer-nav">
                                <ul>
                                    <li><a href="<?php echo esc_url(home_url('/shop')); ?>"><?php esc_html_e('Shop', 'lambo-merch'); ?></a></li>
                                    <li><a href="<?php echo esc_url(home_url('/about')); ?>"><?php esc_html_e('About', 'lambo-merch'); ?></a></li>
                                    <li><a href="<?php echo esc_url(home_url('/contact')); ?>"><?php esc_html_e('Contact', 'lambo-merch'); ?></a></li>
                                    <li><a href="<?php echo esc_url(home_url('/my-account')); ?>"><?php esc_html_e('My Account', 'lambo-merch'); ?></a></li>
                                    <li><a href="/favs-2/"><?php esc_html_e('Favs / Wishlist', 'lambo-merch'); ?></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <!-- Intentionally left blank for spacing -->
                    </div>
                    
                    <div class="col-md-4">
                        <div class="subscribe-section">
                            <h3 class="subscribe-title"><?php esc_html_e('SUBSCRIBE FOR DISCOUNTS & DROPS','lambo-merch'); ?></h3>
                                <div class="email-signup">
                                    <?php 
                                        // Embed WPForms form ID 762 without title/description
                                        echo do_shortcode( '[wpforms id="762" title="false" description="false" captcha="false"]' );
                                    ?>
                            </div>
                            
                            <h3 class="follow-title"><center><?php esc_html_e('FOLLOW', 'lambo-merch'); ?></center></h3>
                            <div class="social-icons">
                                <a href="https://www.instagram.com/bavarianrennsport/" target="_blank" class="social-icon facebook-instagram">
                                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/icons/facebook_instagram.png" alt="Facebook/Instagram">
                                </a>
                                <a href="https://www.youtube.com/channel/UC7z8YdJu3WhzR7jli6qTIqQ" target="_blank" class="social-icon youtube">
                                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/icons/youtube.png" alt="YouTube">
                                </a>
                            </div>
                        </div>
                    </div>
                </div><!-- .row -->
                
                <?php endif; ?>
            </div><!-- .container -->
        </div><!-- .footer-widgets -->
        
        <div class="footer-bottom">
            <!-- Image removed - replaced with CSS background color -->
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="copyright">
                            <p>
                                &copy; <?php echo date('Y'); ?> LAMBO MERCH |
                                <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>"><?php esc_html_e('PRIVACY POLICY', 'lambo-merch'); ?></a> |
                                <a href="<?php echo esc_url(home_url('/terms-of-use')); ?>"><?php esc_html_e('TERMS OF USE', 'lambo-merch'); ?></a> |
                                <?php esc_html_e('WEBSITE DESIGN BY', 'lambo-merch'); ?> <a href="https://mediamade.fresh" target="_blank" class="media-made"><?php esc_html_e('MEDIA MADE FRESH', 'lambo-merch'); ?></a>
                            </p>
                        </div>
                    </div>
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .footer-bottom -->
    </footer><!-- #colophon -->
</div><!-- #page -->

<!-- Global notification container for wishlist messages -->
<div class="lambo-wishlist-message" style="display: none;"></div>

<?php wp_footer(); ?>

<script>
// Only fix the footer email field on the checkout page
document.addEventListener('DOMContentLoaded', function() {
    if (document.body.classList.contains('woocommerce-checkout')) {
        // Fix for footer email input visibility on checkout page
        function fixFooterEmailInput() {
            const footerEmailInputs = document.querySelectorAll('.site-footer input[type="email"], .email-input-wrap input[type="email"], footer input[type="email"]');
            footerEmailInputs.forEach(function(input) {
                input.style.backgroundColor = 'transparent';
                input.style.color = '#ffffff';
                input.style.display = 'inline-block';
                input.style.visibility = 'visible';
                input.style.opacity = '1';
                input.classList.add('footer-email-exempt');
            });
        }
        
        // Run immediately and then periodically
        fixFooterEmailInput();
        setInterval(fixFooterEmailInput, 1000);
    }
    
    // Handle captcha visibility for WPForms
    const wpForm = document.getElementById('wpforms-762');
    if (wpForm) {
        const emailInput = wpForm.querySelector('.wpforms-field-email input[type="email"]');
        if (emailInput) {
            emailInput.addEventListener('focus', function() {
                wpForm.classList.add('form-activated');
            });
            
            emailInput.addEventListener('input', function() {
                if (this.value.length > 0) {
                    wpForm.classList.add('form-activated');
                }
            });
        }
    }
});
</script>

</body>
</html>

<style>
      /* Layout visibility (mobile vs desktop blocks) */
  .mobile-layout { display: none; }
  .desktop-layout { display: block; }
  @media (max-width: 767px) {
    .mobile-layout { display: block!important; }
    .desktop-layout { display: none!important; }
  }

  /* Center and constrain the footer form */
  #wpforms-762 {
    max-width: 800px!important;
    margin: 0 auto!important;
  }

  /* Full-width fields */
  #wpforms-762 .wpforms-field input,
  #wpforms-762 .wpforms-field textarea {
    width: 100%!important;
    background: #282828!important;
    border: none!important;
    color: #fff!important;
    padding: 12px 15px!important;
    border-radius: 4px!important;
    font-size: 14px!important;
    display: block!important;
    margin: 0 0 16px!important;
  }

  /* Two-column rows (first+last name, if you have them) */
  #wpforms-762 .wpforms-field-row {
    display: flex!important;
    justify-content: space-between!important;
    flex-wrap: wrap!important;
    margin-bottom: 16px!important;
  }
  #wpforms-762 .wpforms-one-half {
    width: 48%!important;
    margin: 0 1%!important;
  }

  /* Labels */
  #wpforms-762 .wpforms-field-label {
    font-size: 16px!important;
    color: #fff!important;
    font-weight: 600!important;
    margin-bottom: 8px!important;
  }

  /* Placeholder text */
  #wpforms-762 ::-webkit-input-placeholder { color: #fff!important; }
  #wpforms-762 :-moz-placeholder           { color: #fff!important; opacity: 1!important; }
  #wpforms-762 ::-moz-placeholder          { color: #fff!important; opacity: 1!important; }
  #wpforms-762 :-ms-input-placeholder      { color: #fff!important; }
  #wpforms-762 ::placeholder               { color: #fff!important; }

  /* Focus outline */
  #wpforms-762 .wpforms-field input:focus,
  #wpforms-762 .wpforms-field textarea:focus {
    outline: 2px solid #ff0000!important;
  }

  /* Hide Contact Form 7 invisible captcha initially */
  .cf7ic_instructions {
    display: none!important;
    transition: all 0.3s ease;
  }
  
  /* Show captcha when email field has been interacted with */
  #wpforms-762.form-activated .cf7ic_instructions,
  #wpforms-762 .wpforms-field-email input:not(:placeholder-shown) ~ .cf7ic_instructions,
  #wpforms-762 .wpforms-field-email input:focus ~ .cf7ic_instructions,
  #wpforms-762 .wpforms-field-email:focus-within .cf7ic_instructions {
    display: block!important;
  }
  
  /* Hide captcha wrapper span initially */
  .wpcf7-form-control-wrap.cf7ic-wpf.kc_captcha,
  .wpcf7-form-control-wrap.cf7ic-wpf,
  .wpcf7-form-control-wrap.kc_captcha {
    display: none!important;
    height: 0!important;
    margin: 0!important;
    padding: 0!important;
    transition: all 0.3s ease;
  }
  
  /* Show captcha wrapper when email field has been interacted with */
  #wpforms-762.form-activated .wpcf7-form-control-wrap.cf7ic-wpf.kc_captcha,
  #wpforms-762.form-activated .wpcf7-form-control-wrap.cf7ic-wpf,
  #wpforms-762.form-activated .wpcf7-form-control-wrap.kc_captcha,
  #wpforms-762 .wpforms-field-email input:not(:placeholder-shown) ~ .wpcf7-form-control-wrap.cf7ic-wpf.kc_captcha,
  #wpforms-762 .wpforms-field-email input:not(:placeholder-shown) ~ .wpcf7-form-control-wrap.cf7ic-wpf,
  #wpforms-762 .wpforms-field-email input:not(:placeholder-shown) ~ .wpcf7-form-control-wrap.kc_captcha,
  #wpforms-762 .wpforms-field-email input:focus ~ .wpcf7-form-control-wrap.cf7ic-wpf.kc_captcha,
  #wpforms-762 .wpforms-field-email input:focus ~ .wpcf7-form-control-wrap.cf7ic-wpf,
  #wpforms-762 .wpforms-field-email input:focus ~ .wpcf7-form-control-wrap.kc_captcha,
  #wpforms-762 .wpforms-field-email:focus-within .wpcf7-form-control-wrap.cf7ic-wpf.kc_captcha,
  #wpforms-762 .wpforms-field-email:focus-within .wpcf7-form-control-wrap.cf7ic-wpf,
  #wpforms-762 .wpforms-field-email:focus-within .wpcf7-form-control-wrap.kc_captcha {
    display: block!important;
    height: auto!important;
    margin: 10px 0!important;
    padding: 10px!important;
  }
  
  /* Email input and submit button side by side */
  #wpforms-762 .wpforms-field-container {
    display: flex!important;
    align-items: flex-start!important;
    gap: 10px!important;
  }
  
  #wpforms-762 .wpforms-field-email {
    flex: 1!important;
    margin: 0!important;
  }
  
  #wpforms-762 .wpforms-field-email input {
    width: 100%!important;
    margin: 0!important;
  }
  
  #wpforms-762 .wpforms-submit-container {
    flex-shrink: 0!important;
    margin: 0!important;
  }
  
  /* Arrow-icon submit button */
  #wpforms-762 .wpforms-submit {
    background: #ff0000!important;
    color: #fff!important;
    border: none!important;
    padding: 12px 30px!important;
    font-weight: 600!important;
    display: block!important;
    margin: 20px auto!important;
    cursor: pointer!important;
    width: auto!important;
    height: 46px!important;
  }

  /* Override WPForms “medium” cap */
  #wpforms-762 input.wpforms-field-medium,
  #wpforms-762 select.wpforms-field-medium,
  #wpforms-762 .wpforms-field-row.wpforms-field-medium {
    max-width: none!important;
    width: 100%!important;
  }
/* Specific fix ONLY for checkout page footer email input */
body.woocommerce-checkout .site-footer input[type="email"],
body.woocommerce-checkout footer input[type="email"],
body.woocommerce-checkout .email-input-wrap input[type="email"] {
    background-color: transparent !important;
    color: #ffffff !important;
    display: inline-block !important;
    visibility: visible !important;
    opacity: 1 !important;
    border: none !important;
    width: auto !important;
    height: auto !important;
    padding: 0 !important;
    margin: 0 !important;
    text-indent: 0 !important;
}

/* Only apply this dark background to checkout page */
body.woocommerce-checkout .email-input-wrap {
    background-color: #0b0c10 !important;
}

@media (max-width: 767px) {
    /* Existing mobile styles... */
    
    /* Increase line height for mobile footer links */
    .footer-nav li {
        margin-bottom: -2%; /* Set negative margin as requested */
    }
    
    .footer-nav a {
        line-height: 0.5; /* Add this line to increase spacing */
        padding: 8px 0; /* Add padding for larger touch target */
        font-size: 18px; /* Slightly larger font size */
        display: inline-block; /* Makes the padding work properly */
    }
        /* Footer logo adjustments */
    .footer-logo {
        margin-bottom: -1%;
        margin-top: -10%;
    }

    /* Subscription section spacing */
    .subscribe-section {
        margin-top: 5%;
    }

    /* Copyright text size */
    .copyright {
        font-size: 10px;
    }
    .footer-logo img {
    max-width: 50%; /* Changed from 25% */
    }
    .subscribe-title {
    font-size: 25px;
    }   
    .social-icon img,
    .facebook-instagram img {
        height: 65px;
        max-height: 65px;
    }
    .youtube img {
    height: 70px;
    max-height: 70px;
    }
    .footer-bottom {
    margin-top: -10px;
    }
}    


</style>