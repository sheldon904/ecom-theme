<?php
/**
 * Template Name: Search Results
 * Template Post Type: page
 *
 * A custom template for displaying search results
 *
 * @package Lambo_Merch
 */

get_header(); 
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="search-results-container">
                <h1 class="search-title"><?php esc_html_e('Search Results', 'lambo-merch'); ?></h1>
                
                <div class="search-form-container">
                    <form role="search" method="get" class="woocommerce-product-search custom-search-form" action="<?php echo esc_url(get_permalink()); ?>">
                        <div class="search-input-wrap">
                            <input type="search" id="woocommerce-product-search-field" class="search-field" placeholder="<?php echo esc_attr_x('Search products...', 'placeholder', 'lambo-merch'); ?>" value="<?php echo isset($_GET['s']) ? esc_attr($_GET['s']) : ''; ?>" name="s" />
                            <input type="hidden" name="post_type" value="product" />
                        </div>
                        <button type="submit" class="search-submit">
                            <?php esc_html_e('Search', 'lambo-merch'); ?>
                        </button>
                    </form>
                </div>
                
                <?php
                // Check if there is a search query
                if (isset($_GET['s']) && !empty($_GET['s'])) {
                    $search_term = sanitize_text_field($_GET['s']);
                    
                    // Create a custom query to display search results
                    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                    $search_args = array(
                        'post_type'      => 'product',
                        's'              => $search_term,
                        'posts_per_page' => 12,
                        'paged'          => $paged,
                        'tax_query'      => array(
                            'relation'   => 'OR',
                            array(
                                'taxonomy' => 'product_cat',
                                'field'    => 'name',
                                'terms'    => $search_term,
                                'operator' => 'LIKE'
                            ),
                            array(
                                'taxonomy' => 'product_tag',
                                'field'    => 'name',
                                'terms'    => $search_term,
                                'operator' => 'LIKE'
                            )
                        ),
                        'meta_query'     => array(
                            'relation'    => 'OR',
                            array(
                                'key'     => '_sku',
                                'value'   => $search_term,
                                'compare' => 'LIKE'
                            )
                        )
                    );
                    
                    $search_results = new WP_Query($search_args);
                    
                    if ($search_results->have_posts()) {
                        echo '<div class="search-results-count">';
                        printf(
                            esc_html(_n('Found %d result for "%s"', 'Found %d results for "%s"', $search_results->found_posts, 'lambo-merch')),
                            $search_results->found_posts,
                            esc_html($search_term)
                        );
                        echo '</div>';
                        
                        echo '<div class="search-results-grid">';
                        
                        while ($search_results->have_posts()) {
                            $search_results->the_post();
                            global $product;
                            
                            if (!$product || !$product->is_visible()) {
                                continue;
                            }
                            
                            // Custom product display for search results
                            ?>
                            <div class="search-result-product">
                                <div class="product-image">
                                    <a href="<?php echo esc_url(get_permalink()); ?>">
                                        <?php 
                                        if (has_post_thumbnail()) {
                                            echo get_the_post_thumbnail($product->get_id(), 'woocommerce_thumbnail');
                                        } else {
                                            echo wc_placeholder_img();
                                        }
                                        ?>
                                    </a>
                                </div>
                                
                                <div class="product-details">
                                    <h2 class="product-title">
                                        <a href="<?php echo esc_url(get_permalink()); ?>">
                                            <?php echo esc_html(get_the_title()); ?>
                                        </a>
                                    </h2>
                                    
                                    <?php if ($price_html = $product->get_price_html()): ?>
                                        <span class="price"><?php echo $price_html; ?></span>
                                    <?php endif; ?>
                                    
                                    <a href="<?php echo esc_url(get_permalink()); ?>" class="button see-sizes">
                                        <?php esc_html_e('See Sizes', 'lambo-merch'); ?>
                                    </a>
                                </div>
                            </div>
                            <?php
                        }
                        
                        echo '</div>'; // .search-results-grid
                        
                        // Pagination
                        echo '<div class="search-pagination">';
                        echo paginate_links(array(
                            'base'         => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
                            'total'        => $search_results->max_num_pages,
                            'current'      => max(1, get_query_var('paged')),
                            'format'       => '?paged=%#%',
                            'show_all'     => false,
                            'type'         => 'list',
                            'end_size'     => 2,
                            'mid_size'     => 1,
                            'prev_next'    => true,
                            'prev_text'    => sprintf('<i></i> %1$s', __('Previous', 'lambo-merch')),
                            'next_text'    => sprintf('%1$s <i></i>', __('Next', 'lambo-merch')),
                            'add_args'     => array('s' => $search_term, 'post_type' => 'product'),
                            'add_fragment' => '',
                        ));
                        echo '</div>'; // .search-pagination
                        
                        wp_reset_postdata();
                    } else {
                        echo '<div class="no-results">';
                        echo '<p>' . esc_html__('No products found matching your search criteria.', 'lambo-merch') . '</p>';
                        echo '<a href="' . esc_url(get_permalink(wc_get_page_id('shop'))) . '" class="button continue-shopping">' . esc_html__('Browse Products', 'lambo-merch') . '</a>';
                        echo '</div>';
                    }
                } else {
                    // Display a message when no search has been performed yet
                    echo '<div class="no-search-performed">';
                    echo '<p>' . esc_html__('Enter a search term to find products.', 'lambo-merch') . '</p>';
                    echo '<a href="' . esc_url(get_permalink(wc_get_page_id('shop'))) . '" class="button browse-products">' . esc_html__('Browse All Products', 'lambo-merch') . '</a>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </div>
</div>

<style>
    /* Search Results Page Styling */
    .search-results-container {
        padding: 40px 0;
    }
    
    .search-title {
        margin-bottom: 30px;
        text-align: center;
        color: #fff;
        text-transform: uppercase;
        font-size: 32px;
    }
    
    .search-form-container {
        max-width: 800px;
        margin: 0 auto 40px;
    }
    
    .custom-search-form {
        display: flex;
        justify-content: center;
        align-items: center;
    }
    
    .search-input-wrap {
        flex: 1;
        margin-right: 15px;
        position: relative;
    }
    
    .search-field {
        width: 100%;
        padding: 12px 15px;
        background-color: #222;
        border: 1px solid #444;
        color: #fff;
        font-size: 16px;
        border-radius: 0;
        transition: border-color 0.3s ease;
    }
    
    .search-field:focus {
        outline: none;
        border-color: #C8B100; /* Gold color */
    }
    
    .search-submit {
        background-color: #C8B100; /* Gold color */
        color: #000;
        padding: 12px 30px;
        border: none;
        cursor: pointer;
        text-transform: uppercase;
        font-weight: bold;
        border-radius: 0;
        transition: background-color 0.3s ease;
    }
    
    .search-submit:hover {
        background-color: #a99600; /* Darker gold */
    }
    
    .search-results-count {
        margin-bottom: 30px;
        text-align: center;
        font-size: 18px;
        color: #fff;
    }
    
    /* Grid layout for search results */
    .search-results-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 30px;
        margin-bottom: 40px;
    }
    
    .search-result-product {
        background-color: #222;
        border: 1px solid #444;
        transition: transform 0.3s ease;
    }
    
    .search-result-product:hover {
        transform: translateY(-5px);
    }
    
    .product-image {
        position: relative;
        overflow: hidden;
        padding-top: 100%; /* 1:1 Aspect Ratio */
    }
    
    .product-image a {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .product-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s ease;
    }
    
    .search-result-product:hover .product-image img {
        transform: scale(1.05);
    }
    
    .product-details {
        padding: 20px;
        text-align: center;
    }
    
    .product-title {
        font-size: 18px;
        margin-bottom: 10px;
        font-weight: bold;
        line-height: 1.3;
    }
    
    .product-title a {
        color: #fff;
        text-decoration: none;
        transition: color 0.3s ease;
    }
    
    .product-title a:hover {
        color: #C8B100; /* Gold color */
    }
    
    .price {
        display: block;
        margin-bottom: 15px;
        font-size: 18px;
        color: #C8B100; /* Gold color */
        font-weight: bold;
    }
    
    .see-sizes {
        display: inline-block;
        background-color: #C8B100; /* Gold color */
        color: #000 !important;
        padding: 10px 20px;
        text-transform: uppercase;
        font-weight: bold;
        text-decoration: none;
        transition: background-color 0.3s ease;
    }
    
    .see-sizes:hover {
        background-color: #a99600; /* Darker gold */
    }
    
    /* No results message */
    .no-results,
    .no-search-performed {
        text-align: center;
        padding: 50px 0;
    }
    
    .no-results p,
    .no-search-performed p {
        font-size: 18px;
        margin-bottom: 20px;
        color: #fff;
    }
    
    .continue-shopping,
    .browse-products {
        display: inline-block;
        background-color: #C8B100; /* Gold color */
        color: #000 !important;
        padding: 12px 24px;
        text-transform: uppercase;
        font-weight: bold;
        text-decoration: none;
        transition: background-color 0.3s ease;
    }
    
    .continue-shopping:hover,
    .browse-products:hover {
        background-color: #a99600; /* Darker gold */
    }
    
    /* Pagination */
    .search-pagination {
        text-align: center;
        margin-top: 30px;
    }
    
    .search-pagination .page-numbers {
        display: inline-block;
        list-style: none;
        margin: 0;
        padding: 0;
    }
    
    .search-pagination .page-numbers li {
        display: inline-block;
        margin: 0 5px;
    }
    
    .search-pagination .page-numbers li a,
    .search-pagination .page-numbers li span {
        display: inline-block;
        padding: 8px 12px;
        background-color: #222;
        color: #fff;
        text-decoration: none;
        transition: all 0.3s ease;
    }
    
    .search-pagination .page-numbers li span.current {
        background-color: #C8B100;
        color: #000;
    }
    
    .search-pagination .page-numbers li a:hover {
        background-color: #444;
    }
    
    /* Mobile styles */
    @media (max-width: 991px) {
        .search-results-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }
    
    @media (max-width: 767px) {
        .custom-search-form {
            flex-direction: column;
        }
        
        .search-input-wrap {
            width: 100%;
            margin-right: 0;
            margin-bottom: 15px;
        }
        
        .search-submit {
            width: 100%;
        }
        
        .search-results-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<?php get_footer(); ?>