<?php
/**
 * Template Name: Blank Template
 *
 * A completely blank template that only outputs what's in the editor content.
 *
 * @package Lambo_Merch
 */

// No header or footer included

?>
<div class="blank-template-content">
    <?php
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
    ?>
</div>