<?php
/**
 * Template Name: Home Page
 *
 * The template for displaying the home page.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Lambo_Merch
 */

get_header();
?>

<main id="primary" class="site-main">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <img src="http://ecom-test.local/wp-content/uploads/2025/04/Big_LM_logo.png" alt="Lamborghini Merch Logo" class="img-fluid" />
                <h1>Luxury Merch for Lambo Enthusiasts</h1>
            </div>

            <div class="col-sm-12 text-center">
                <img src="http://ecom-test.local/wp-content/uploads/2025/04/Shop_Box.png" alt="Lamborghini T-shirts for sale shop box" class="img-fluid" />
            </div>

            <div class="col-sm-12 text-center">
                <img src="http://ecom-test.local/wp-content/uploads/2025/04/Video.png" alt="Lamborghini Video" class="img-fluid" />
            </div>
        </div>
    </div>
</main>

<?php
get_footer();