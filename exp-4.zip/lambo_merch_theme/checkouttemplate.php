<?php
/**
 * Template Name: Checkout Template
 * Description: A custom checkout page template for Lambo Merch.
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="primary" class="site-main custom-checkout-page">
  <div class="container">
    <h2 class="checkout-heading">Checkout</h2>
    
    <?php 
    // Output the WooCommerce checkout form using the shortcode
    echo do_shortcode('[woocommerce_checkout]'); 
    ?>
  </div>
</main>

<style>
/* Main checkout styling */
.custom-checkout-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
  color: #ffffff;
}

/* Checkout heading */
.checkout-heading {
  color: #ff0000;
  font-style: italic;
  margin-bottom: 1.5rem;
  font-size: 2rem;
  text-align: left;
}

/* Returning customer and coupon section */
.woocommerce-form-coupon-toggle,
.woocommerce-form-login-toggle {
  background-color: #333333;
  padding: 15px;
  margin-bottom: 15px;
  width: 100%;
  color: #ffffff;
}

.woocommerce-form-coupon-toggle .showcoupon,
.woocommerce-form-login-toggle .showlogin {
  color: #ffffff;
  text-decoration: underline;
  cursor: pointer;
}

/* Coupon form */
.checkout_coupon.woocommerce-form-coupon {
  background-color: #222222;
  padding: 15px;
  margin-bottom: 15px;
  border: none;
  border-radius: 0;
}

.checkout_coupon.woocommerce-form-coupon input {
  background-color: #333333;
  border: 1px solid #444444;
  color: #ffffff;
  padding: 10px;
}

.checkout_coupon.woocommerce-form-coupon button {
  background-color: #ff0000;
  color: #ffffff;
  border: none;
  padding: 10px 15px;
}

/* Billing details section */
.woocommerce-billing-fields h3,
.woocommerce-shipping-fields h3 {
  color: #ff0000;
  font-style: italic;
  margin-bottom: 1.5rem;
  font-size: 1.8rem;
}

/* Position "Ship to different address" checkbox next to heading */
.woocommerce-shipping-fields {
  position: relative;
}

.woocommerce-shipping-fields h3#ship-to-different-address {
  display: flex;
  align-items: center;
  position: absolute;
  top: -60px;
  right: 0;
}

.woocommerce-shipping-fields h3#ship-to-different-address .woocommerce-form__input-checkbox {
  margin-right: 8px;
}

/* Billing and shipping fields */
.woocommerce-checkout .form-row label {
  color: #ffffff;
}

.woocommerce-checkout .form-row .woocommerce-input-wrapper input,
.woocommerce-checkout .form-row .woocommerce-input-wrapper select,
.woocommerce-checkout .form-row .woocommerce-input-wrapper textarea {
  background-color: #333333;
  border: 1px solid #444444;
  color: #ffffff;
  padding: 12px;
}

/* Order summary section */
.woocommerce-checkout-review-order-table {
  background-color: #222222;
  color: #ffffff;
}

.woocommerce-checkout-review-order-table th,
.woocommerce-checkout-review-order-table td {
  color: #ffffff;
  padding: 15px;
}

/* Fix image and product name display */
.woocommerce-checkout-review-order-table .product-name {
  display: flex;
  align-items: center;
}

.woocommerce-checkout-review-order-table .product-name img {
  margin-right: 15px;
  width: 60px;
  height: auto;
}

/* Payment section */
#payment {
  background-color: #000000;
  color: #ffffff;
  border-radius: 0;
}

#payment .payment_box {
  background-color: #333333;
  color: #ffffff;
}

#payment .payment_box::before {
  border-bottom-color: #333333;
}

#payment .payment_methods {
  border-bottom: 1px solid #333333;
}

#payment .payment_methods label {
  color: #ffffff;
}

/* Stripe elements */
.wc-stripe-elements-field,
.wc-stripe-iban-element-field {
  background-color: #333333;
  border: 1px solid #444444;
  padding: 15px;
}

/* Place order button */
#place_order {
  background-color: #ff0000;
  color: #ffffff;
  padding: 15px 30px;
  text-transform: uppercase;
  font-weight: bold;
  width: 100%;
}

/* Create account checkbox */
.woocommerce-account-fields {
  margin-top: 20px;
}

.woocommerce-account-fields label {
  color: #ffffff;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .woocommerce-shipping-fields h3#ship-to-different-address {
    position: static;
    margin-top: 20px;
    margin-bottom: 20px;
  }
}
</style>

<script>
jQuery(document).ready(function($) {
  // Fix for checkout elements layout
  function adjustCheckoutLayout() {
    // Move shipping checkbox next to billing details heading if not already there
    const billingHeading = $('.woocommerce-billing-fields h3');
    const shippingHeading = $('#ship-to-different-address');
    
    if (billingHeading.length && shippingHeading.length && $(window).width() > 768) {
      billingHeading.parent().css('position', 'relative');
      shippingHeading.css({
        'position': 'absolute',
        'top': billingHeading.position().top,
        'right': '0'
      });
    } else {
      shippingHeading.css({
        'position': 'static',
        'top': 'auto',
        'right': 'auto'
      });
    }
    
    // Add thumbnail images to product names in order review
    if (!$('.product-name img').length) {
      $('.woocommerce-checkout-review-order-table .product-name').each(function() {
        const productId = $(this).find('strong').data('product-id');
        if (productId) {
          // You would need to fetch the product image URL here
          // As a placeholder, we'll add a span for now
          $(this).prepend('<span class="product-thumbnail"></span>');
        }
      });
    }
  }
  
  // Run layout adjustments on page load and window resize
  adjustCheckoutLayout();
  $(window).on('resize', adjustCheckoutLayout);
  
  // Make sure coupon toggle works properly
  $('.showcoupon').on('click', function(e) {
    e.preventDefault();
    $('.checkout_coupon').slideToggle(400, function() {
      if ($(this).is(':visible')) {
        $(this).find('input[name="coupon_code"]').focus();
      }
    });
  });
  
  // Apply custom styling to Stripe elements when loaded
  function styleStripeElements() {
    $('.wc-stripe-elements-field, .wc-stripe-iban-element-field').css({
      'background-color': '#333333',
      'border': '1px solid #444444',
      'padding': '15px'
    });
    
    // The iframe is in a shadow DOM, so we can't style it directly
    // But we can style its container
    $('.stripe-card-group, .wc-stripe-elements-field').css({
      'background-color': '#333333',
      'padding': '15px'
    });
  }
  
  // Check for Stripe elements periodically and style them
  const stripeCheck = setInterval(() => {
    const stripeElements = $('.wc-stripe-elements-field, .stripe-card-group');
    if (stripeElements.length) {
      styleStripeElements();
      clearInterval(stripeCheck);
    }
  }, 500);
});
</script>

<?php
get_footer();
?>