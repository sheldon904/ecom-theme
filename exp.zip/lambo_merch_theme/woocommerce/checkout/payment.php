<?php
/**
 * Checkout Payment Section
 *
 * This template overrides /woocommerce/checkout/payment.php
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 8.0.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! wp_doing_ajax() ) {
	do_action( 'woocommerce_review_order_before_payment' );
}
?>

<div id="payment" class="woocommerce-checkout-payment">
	<!-- CUSTOM ADDITION: Express Payment Section -->
	<div class="express-checkout-section">
		<div class="express-payment-title">
			<h3><?php _e('Express Checkout', 'lambo-merch'); ?></h3>
		</div>
		<div class="express-payment-buttons">
			<?php
			// Method 1: Standard WooCommerce hook for express checkout
			do_action('woocommerce_checkout_before_customer_details');
			
			// Method 2: Try to directly output Stripe buttons
			if (class_exists('WC_Stripe_Payment_Request')) {
				$payment_request = WC_Stripe_Payment_Request::instance();
				if (method_exists($payment_request, 'payment_request_button')) {
					$payment_request->payment_request_button();
				}
			}
			
			// Method 3: Try using Stripe gateway directly
			$available_gateways = WC()->payment_gateways()->get_available_payment_gateways();
			if (isset($available_gateways['stripe'])) {
				$stripe_gateway = $available_gateways['stripe'];
				if (method_exists($stripe_gateway, 'get_request_button_html')) {
					echo $stripe_gateway->get_request_button_html();
				}
			}
			
			// Method 4: Output Express Checkout manually using WooCommerce blocks
			echo '<div class="wp-block-woocommerce-checkout-express-payment-block"></div>';
			?>
		</div>
		<div class="express-payment-or">
			<span><?php _e('OR', 'lambo-merch'); ?></span>
		</div>
	</div>
	<!-- End of Express Payment Section -->

	<?php if ( WC()->cart->needs_payment() ) : ?>
		<ul class="wc_payment_methods payment_methods methods">
			<?php
			if ( ! empty( $available_gateways ) ) {
				foreach ( $available_gateways as $gateway ) {
					wc_get_template( 'checkout/payment-method.php', array( 'gateway' => $gateway ) );
				}
			} else {
				echo '<li class="woocommerce-notice woocommerce-notice--info woocommerce-info">' . apply_filters( 'woocommerce_no_available_payment_methods_message', WC()->customer->get_billing_country() ? esc_html__( 'Sorry, it seems that there are no available payment methods for your state. Please contact us if you require assistance or wish to make alternate arrangements.', 'woocommerce' ) : esc_html__( 'Please fill in your details above to see available payment methods.', 'woocommerce' ) ) . '</li>'; // @codingStandardsIgnoreLine
			}
			?>
		</ul>
	<?php endif; ?>
	<div class="form-row place-order">
		<noscript>
			<?php
			/* translators: $1 and $2 opening and closing emphasis tags respectively */
			printf( esc_html__( 'Since your browser does not support JavaScript, or it is disabled, please ensure you click the %1$sUpdate Totals%2$s button before placing your order. You may be charged more than the amount stated above if you fail to do so.', 'woocommerce' ), '<em>', '</em>' );
			?>
			<br/><button type="submit" class="button alt<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" name="woocommerce_checkout_update_totals" id="place_order" value="<?php esc_attr_e( 'Update totals', 'woocommerce' ); ?>"><?php esc_html_e( 'Update totals', 'woocommerce' ); ?></button>
		</noscript>

		<?php wc_get_template( 'checkout/terms.php' ); ?>

		<?php do_action( 'woocommerce_review_order_before_submit' ); ?>

		<?php echo apply_filters( 'woocommerce_order_button_html', '<button type="submit" class="button alt' . esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ) . '" name="woocommerce_checkout_place_order" id="place_order" value="' . esc_attr( $order_button_text ) . '" data-value="' . esc_attr( $order_button_text ) . '">' . esc_html( $order_button_text ) . '</button>' ); // @codingStandardsIgnoreLine ?>

		<?php do_action( 'woocommerce_review_order_after_submit' ); ?>

		<?php wp_nonce_field( 'woocommerce-process_checkout', 'woocommerce-process-checkout-nonce' ); ?>
	</div>
</div>
<?php
if ( ! wp_doing_ajax() ) {
	do_action( 'woocommerce_review_order_after_payment' );
}