jQuery(document).ready(function($) {
    // Desktop and mobile menu toggle
    $('.menu-toggle, .mobile-menu-toggle').click(function(e) {
        e.preventDefault();
        $('body').toggleClass('menu-open');
        $('#site-navigation').toggleClass('toggled');
    });
    
    // Close button for menu
    $('.close-menu').click(function(e) {
        e.preventDefault();
        $('body').removeClass('menu-open');
        $('#site-navigation').removeClass('toggled');
    });
    
    // Email form focus effect
    $('.email-placeholder').click(function() {
        $(this).fadeOut(200, function() {
            $(this).siblings('input[type="email"]').focus();
            $(this).siblings('.arrow-btn').show();
        });
    });
    
    // Email form blur effect if empty
    $('input[type="email"]').blur(function() {
        if ($(this).val() === '') {
            $(this).siblings('.arrow-btn').hide();
            $(this).siblings('.email-placeholder').fadeIn(200);
        }
    });
    
    // Fixed header on scroll
    var $header = $('.site-header');
    var headerHeight = $header.outerHeight();
    
    $(window).scroll(function() {
        if ($(this).scrollTop() > 50) {
            $header.addClass('fixed');
            $('body').css('padding-top', headerHeight);
        } else {
            $header.removeClass('fixed');
            $('body').css('padding-top', 0);
        }
    });
    
    // Search functionality
    var desktopSearchActive = false;
    var mobileSearchActive = false;
    
    // Desktop search toggle
    $('.header-icon-link.search-icon').click(function(e) {
        e.preventDefault();
        
        if (!desktopSearchActive) {
            // Store the original content to restore later
            var $searchContainer = $(this);
            var originalContent = $searchContainer.html();
            
            // Replace with search form
            $searchContainer.html('<form role="search" method="get" class="header-search-form" action="' + site_url + '">' +
                '<input type="search" class="search-field" placeholder="Search products..." value="" name="s" />' +
                '<input type="hidden" name="post_type" value="product" />' +
                '<button type="submit" class="search-submit">Search</button>' +
                '<button type="button" class="close-search">×</button>' +
                '</form>');
            
            // Focus on the search field
            $searchContainer.find('.search-field').focus();
            
            // Close search when clicking the close button
            $searchContainer.find('.close-search').click(function(e) {
                e.stopPropagation();
                $searchContainer.html(originalContent);
                desktopSearchActive = false;
            });
            
            desktopSearchActive = true;
        }
    });
    
    // Mobile search toggle
    $('.mobile-header .search-icon').click(function(e) {
        e.preventDefault();
        
        if (!mobileSearchActive) {
            // Create mobile search form if it doesn't exist
            if ($('.mobile-search-form-container').length === 0) {
                $('.mobile-header').after('<div class="mobile-search-form-container">' +
                    '<form role="search" method="get" class="mobile-search-form" action="' + site_url + '">' +
                    '<div class="search-input-wrap">' +
                    '<input type="search" class="search-field" placeholder="Search products..." value="" name="s" />' +
                    '<input type="hidden" name="post_type" value="product" />' +
                    '</div>' +
                    '<div class="search-buttons">' +
                    '<button type="submit" class="search-submit">Search</button>' +
                    '<button type="button" class="close-search">Cancel</button>' +
                    '</div>' +
                    '</form>' +
                    '</div>');
            }
            
            // Show the search form
            $('.mobile-search-form-container').slideDown(200);
            $('.mobile-search-form-container .search-field').focus();
            
            // Set up the close button
            $('.mobile-search-form-container .close-search').click(function() {
                $('.mobile-search-form-container').slideUp(200);
                mobileSearchActive = false;
            });
            
            mobileSearchActive = true;
        } else {
            // Hide the search form if already active
            $('.mobile-search-form-container').slideUp(200);
            mobileSearchActive = false;
        }
    });
    
    // Close search when clicking outside
    $(document).on('click', function(e) {
        if (desktopSearchActive && !$(e.target).closest('.header-search-form').length && !$(e.target).closest('.header-icon-link.search-icon').length) {
            $('.header-icon-link.search-icon').html('<span class="icon-text">SEARCH</span>' +
                '<span style="position: absolute; width: 100%; height: 100%; z-index: 1;"></span>' +
                '<img src="' + theme_url + '/images/icons/search.png" alt="Search" class="header-icon">');
            desktopSearchActive = false;
        }
        
        if (mobileSearchActive && !$(e.target).closest('.mobile-search-form-container').length && !$(e.target).closest('.mobile-header .search-icon').length) {
            $('.mobile-search-form-container').slideUp(200);
            mobileSearchActive = false;
        }
    });
    
    // Wishlist link click handler
    $('a[href$="/wishlist"]').click(function(e) {
        e.preventDefault();
        window.location.href = '/wishlist';
    });
    
    // Product tabs
    $('.tab-link').click(function(e) {
        e.preventDefault();
        
        var tab_id = $(this).attr('data-tab');
        
        $('.tab-link').parent().removeClass('active');
        $('.tab-content').removeClass('active');
        
        $(this).parent().addClass('active');
        $("#"+tab_id).addClass('active');
    });
    
    // Quantity buttons
    $('.quantity-button.minus').click(function() {
        var input = $(this).siblings('input.qty');
        var val = parseInt(input.val());
        if (val > 1) {
            input.val(val - 1).change();
        }
    });
    
    $('.quantity-button.plus').click(function() {
        var input = $(this).siblings('input.qty');
        var val = parseInt(input.val());
        var max = parseInt(input.attr('max'));
        
        if (!max || val < max) {
            input.val(val + 1).change();
        }
    });
});