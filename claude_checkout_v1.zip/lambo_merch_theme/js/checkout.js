/**
 * Custom JavaScript for the checkout page
 */
document.addEventListener('DOMContentLoaded', function() {
    // Hide express checkout section
    const expressPaymentBlock = document.querySelector('.wp-block-woocommerce-checkout-express-payment-block');
    if (expressPaymentBlock) {
        expressPaymentBlock.style.display = 'none';
    }
    
    // Hide coupon form in totals
    const couponFormBlock = document.querySelector('.wp-block-woocommerce-checkout-order-summary-coupon-form-block');
    if (couponFormBlock) {
        couponFormBlock.style.display = 'none';
    }

    // Apply custom styling to input fields
    const styleFormFields = function() {
        // All text input fields
        const inputFields = document.querySelectorAll(
            '.wc-block-components-text-input input[type="text"], ' +
            '.wc-block-components-text-input input[type="email"], ' + 
            '.wc-block-components-text-input input[type="tel"], ' +
            '.wc-block-components-text-input input[type="number"], ' +
            '.woocommerce-input-wrapper input, ' +
            '.woocommerce-input-wrapper textarea, ' +
            '.wc-credit-card-form-card-number, ' +
            '.wc-credit-card-form-card-expiry, ' +
            '.wc-credit-card-form-card-cvc'
        );
        
        inputFields.forEach(field => {
            field.style.backgroundColor = '#333333';
            field.style.border = '1px solid #444444';
            field.style.color = '#ffffff';
            field.style.padding = '12px';
            field.style.borderRadius = '0';
            field.style.fontSize = '16px';
            
            // Add focus event handlers for better user experience
            field.addEventListener('focus', function() {
                this.style.borderColor = '#ff0000';
                this.style.boxShadow = 'none';
            });
            
            field.addEventListener('blur', function() {
                this.style.borderColor = '#444444';
            });
        });
        
        // Select dropdowns
        const selectFields = document.querySelectorAll(
            'select.select, ' +
            '.woocommerce-input-wrapper select, ' +
            '.wc-block-components-select .components-custom-select-control__button'
        );
        
        selectFields.forEach(select => {
            select.style.backgroundColor = '#333333';
            select.style.border = '1px solid #444444';
            select.style.color = '#ffffff';
            select.style.padding = '12px';
            select.style.borderRadius = '0';
            select.style.fontSize = '16px';
        });
    };
    
    // Run immediately
    styleFormFields();
    
    // Set up a MutationObserver to catch dynamically loaded elements
    const bodyObserver = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes && mutation.addedNodes.length > 0) {
                // Check if any of the added nodes are relevant
                for (let i = 0; i < mutation.addedNodes.length; i++) {
                    const node = mutation.addedNodes[i];
                    if (node.nodeType === 1) { // ELEMENT_NODE
                        // Re-run our styling function
                        styleFormFields();
                        
                        // Hide elements again if they've been re-added
                        const express = document.querySelector('.wp-block-woocommerce-checkout-express-payment-block');
                        if (express) express.style.display = 'none';
                        
                        const coupon = document.querySelector('.wp-block-woocommerce-checkout-order-summary-coupon-form-block');
                        if (coupon) coupon.style.display = 'none';
                    }
                }
            }
        });
    });
    
    // Start observing the document body for DOM changes
    bodyObserver.observe(document.body, {
        childList: true,
        subtree: true
    });
});