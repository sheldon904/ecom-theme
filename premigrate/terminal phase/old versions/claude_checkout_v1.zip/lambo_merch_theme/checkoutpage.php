<?php
/**
 * Template Name: Checkout Page Template
 * Description: A custom checkout page template for Lambo Merch.
 */

defined( 'ABSPATH' ) || exit;

get_header();

// Remove any notices that might interfere with our custom design
wc_clear_notices();

?>

<style>
/* Custom Checkout Form Styling */
.wc-block-checkout {
  background: #222222;
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
  color: #ffffff;
}

/* Custom input styling */
.wc-block-components-text-input input[type="text"],
.wc-block-components-text-input input[type="email"],
.wc-block-components-text-input input[type="tel"],
.wc-block-components-text-input input[type="number"],
.wc-block-components-text-input textarea,
.wc-block-components-select .components-custom-select-control__button {
  background-color: #333333 !important;
  border: 1px solid #444444 !important;
  color: #ffffff !important;
  padding: 12px !important;
  border-radius: 0 !important;
  font-size: 16px !important;
}

/* Label styling */
.wc-block-components-text-input label,
.wc-block-components-select label {
  color: #ffffff !important;
  font-weight: bold !important;
}

/* Payment method styling */
.wc-block-components-payment-method-label {
  color: #ffffff !important;
}

.wc-block-components-payment-method-icons {
  display: flex;
  margin-top: 10px;
}

/* Card fields styling */
.wc-block-components-form .wc-block-components-text-input.wc-block-components-card-form-input {
  background-color: #333333 !important;
  border: 1px solid #444444 !important;
  color: #ffffff !important;
}

/* Hide express payment section */
.wp-block-woocommerce-checkout-express-payment-block {
  display: none !important;
}

/* Remove coupon section in totals */
.wp-block-woocommerce-checkout-order-summary-coupon-form-block {
  display: none !important;
}

/* Order summary styling */
.wp-block-woocommerce-checkout-order-summary-block {
  background: #333333;
  padding: 1.5rem;
}

/* Place order button */
.wc-block-components-checkout-place-order-button {
  background-color: #ff0000 !important;
  color: #ffffff !important;
  text-transform: uppercase !important;
  font-weight: bold !important;
  padding: 1rem 2rem !important;
  border: none !important;
  width: 100% !important;
  transition: background-color 0.3s ease !important;
}

.wc-block-components-checkout-place-order-button:hover {
  background-color: #cc0000 !important;
}

/* Mobile-specific styles */
@media (max-width: 767px) {
  .wc-block-checkout {
    padding: 1rem;
  }
  
  /* Stack fields better on mobile */
  .wc-block-components-checkout-step {
    padding-left: 0 !important;
    padding-right: 0 !important;
  }
}
</style>

<main id="primary" class="site-main">
  <div class="checkout-container" style="max-width:1200px; margin:0 auto; padding:2rem;">
    <h1 class="page-title" style="text-align:center; margin-bottom:2rem; color:#ff0000; font-style:italic;">
      Checkout
    </h1>
    
    <?php
    // Output custom WooCommerce checkout form
    echo do_shortcode('[woocommerce_checkout]');
    ?>
    
    <script>
    // Script to apply custom styling to dynamically loaded elements
    document.addEventListener('DOMContentLoaded', function() {
      // Hide express checkout section (backup method if CSS doesn't catch it)
      const expressPaymentBlock = document.querySelector('.wp-block-woocommerce-checkout-express-payment-block');
      if (expressPaymentBlock) {
        expressPaymentBlock.style.display = 'none';
      }
      
      // Hide coupon form in totals (backup method if CSS doesn't catch it)
      const couponFormBlock = document.querySelector('.wp-block-woocommerce-checkout-order-summary-coupon-form-block');
      if (couponFormBlock) {
        couponFormBlock.style.display = 'none';
      }
      
      // Apply custom styling to credit card fields when they appear
      const applyCardFieldStyling = function() {
        const cardFields = document.querySelectorAll('.wc-block-components-text-input input[type="text"], .wc-credit-card-form-card-number, .wc-credit-card-form-card-expiry, .wc-credit-card-form-card-cvc');
        cardFields.forEach(field => {
          field.style.backgroundColor = '#333333';
          field.style.border = '1px solid #444444';
          field.style.color = '#ffffff';
          field.style.padding = '12px';
          field.style.borderRadius = '0';
          field.style.fontSize = '16px';
        });
      };
      
      // Initial application
      applyCardFieldStyling();
      
      // Re-apply when payment method changes (they might load dynamically)
      const paymentMethodObserver = new MutationObserver(function(mutations) {
        applyCardFieldStyling();
      });
      
      const paymentMethodsContainer = document.querySelector('.wc-block-components-payment-method-icons');
      if (paymentMethodsContainer) {
        paymentMethodObserver.observe(paymentMethodsContainer, { childList: true, subtree: true });
      }
    });
    </script>
  </div>
</main>

<?php
get_footer();