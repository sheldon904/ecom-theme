<?php
/**
 * Template Name: Checkout Template
 * Description: A custom checkout page template for Lambo Merch.
 */

defined( 'ABSPATH' ) || exit;

get_header();

// Remove any notices that might be visible
wc_clear_notices();
?>

<style>
/* Mobile-specific styles */
@media (max-width: 767px) {
  .mobile-layout { display: block !important; }
  .desktop-layout { display: none !important; }
}

/* Desktop-specific styles */
@media (min-width: 768px) {
  .desktop-layout { display: block !important; }
  .mobile-layout { display: none !important; }
}

/* Checkout specific styles */
.checkout-heading {
  color: #ff0000;
  font-style: italic;
  margin-bottom: 1.5rem;
  font-size: 2rem;
}

.checkout-info-box {
  background-color: #333333;
  padding: 15px;
  margin-bottom: 15px;
  width: 100%;
  color: #ffffff;
}

.checkout-link {
  color: #ffffff;
  text-decoration: underline;
  cursor: pointer;
}

.coupon-form {
  display: none;
  background-color: #222222;
  padding: 15px;
  margin-bottom: 15px;
  width: 100%;
}

.coupon-form input[type="text"] {
  width: 70%;
  padding: 10px;
  background-color: #333333;
  border: 1px solid #444444;
  color: #ffffff;
}

.coupon-form button {
  width: 25%;
  padding: 10px;
  background-color: #ff0000;
  border: none;
  color: #ffffff;
  cursor: pointer;
  margin-left: 5%;
}

.billing-details {
  margin-top: 30px;
  margin-bottom: 20px;
}

.billing-form {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
}

.billing-column {
  flex: 1;
  min-width: 300px;
}

.shipping-column {
  flex: 1;
  min-width: 300px;
}

.form-row {
  margin-bottom: 15px;
}

.form-row input[type="text"],
.form-row input[type="email"],
.form-row input[type="tel"],
.form-row select {
  width: 100%;
  padding: 12px;
  background-color: #333333;
  border: 1px solid #444444;
  color: #ffffff;
}

.checkbox-row {
  margin: 15px 0;
  display: flex;
  align-items: center;
}

.checkbox-row input[type="checkbox"] {
  margin-right: 10px;
}

.order-summary {
  margin-top: 30px;
  background-color: #222222;
  padding: 20px;
}

.order-summary-heading {
  margin-bottom: 20px;
  color: #ff0000;
  font-style: italic;
}

.order-item {
  display: flex;
  align-items: center;
  margin-bottom: 15px;
  padding-bottom: 15px;
  border-bottom: 1px solid #333333;
}

.order-item-image {
  width: 60px;
  height: 60px;
  margin-right: 15px;
}

.order-item-details {
  flex: 1;
}

.order-item-name {
  font-weight: bold;
  color: #ffffff;
}

.order-item-price {
  color: #ffffff;
}

.order-item-quantity {
  width: 60px;
  text-align: center;
  margin: 0 15px;
}

.order-item-total {
  color: #ffffff;
  font-weight: bold;
  width: 80px;
  text-align: right;
}

.order-totals {
  margin-top: 20px;
}

.order-total-row {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
}

.order-total-label {
  color: #ffffff;
}

.order-total-value {
  color: #ffffff;
  font-weight: bold;
}

.payment-methods {
  margin-top: 30px;
}

.payment-option {
  margin-bottom: 15px;
  display: flex;
  align-items: center;
}

.payment-option input[type="radio"] {
  margin-right: 10px;
}

.payment-icons {
  display: flex;
  gap: 5px;
  margin-top: 10px;
}

.payment-icon {
  width: 40px;
  height: 25px;
  background-color: #ffffff;
  border-radius: 3px;
}

.place-order-button {
  background-color: #ff0000;
  color: #ffffff;
  padding: 15px 30px;
  border: none;
  text-transform: uppercase;
  font-weight: bold;
  margin-top: 20px;
  cursor: pointer;
  width: 100%;
}

@media (max-width: 767px) {
  .billing-form {
    flex-direction: column;
  }
  
  .billing-column,
  .shipping-column {
    width: 100%;
  }
  
  .order-item {
    flex-wrap: wrap;
  }
  
  .order-item-quantity,
  .order-item-total {
    margin-top: 10px;
  }
}
</style>

<main id="primary" class="site-main" style="max-width:1200px; margin:0 auto; padding:2rem;">

  <!-- DESKTOP LAYOUT -->
  <div class="desktop-layout">
    <h2 class="checkout-heading">Checkout</h2>
    
    <!-- Returning customer info box -->
    <div class="checkout-info-box">
      <p>Returning customer? <span class="checkout-link" id="login-trigger">Click here to login</span></p>
    </div>
    
    <!-- Login form (hidden by default) -->
    <div id="login-form" style="display: none; margin-bottom: 15px;">
      <?php 
      // Display the WooCommerce login form
      woocommerce_login_form(array(
        'message' => '',
        'redirect' => wc_get_checkout_url(),
        'hidden' => false,
      )); 
      ?>
    </div>
    
    <!-- Coupon info box -->
    <div class="checkout-info-box">
      <p>Have a coupon? <span class="checkout-link" id="coupon-trigger">Click here to enter your code</span></p>
    </div>
    
    <!-- Coupon form (hidden by default) -->
    <div id="coupon-form" class="coupon-form">
      <form method="post" action="<?php echo esc_url(wc_get_cart_url()); ?>">
        <input type="text" name="coupon_code" placeholder="Coupon code">
        <button type="submit" class="button" name="apply_coupon" value="Apply coupon">Apply</button>
        <?php wp_nonce_field('woocommerce-cart', 'woocommerce-cart-nonce'); ?>
      </form>
    </div>
    
    <!-- Billing/Shipping Details -->
    <div class="billing-details">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2 class="checkout-heading" style="margin-bottom: 0;">Billing Details</h2>
        <div class="checkbox-row" style="margin: 0;">
          <input type="checkbox" name="ship_to_different_address" id="ship_to_different_address" value="1">
          <label for="ship_to_different_address">Ship to a different address?</label>
        </div>
      </div>
      
      <form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url(wc_get_checkout_url()); ?>" enctype="multipart/form-data">
        
        <div class="billing-form">
          <!-- Left column - Billing details -->
          <div class="billing-column">
            <div class="form-row">
              <input type="text" name="billing_first_name" id="billing_first_name" placeholder="First name *" required>
            </div>
            
            <div class="form-row">
              <input type="text" name="billing_last_name" id="billing_last_name" placeholder="Last name *" required>
            </div>
            
            <div class="form-row">
              <input type="text" name="billing_company" id="billing_company" placeholder="Company (optional)">
            </div>
            
            <div class="form-row">
              <input type="text" name="billing_address_1" id="billing_address_1" placeholder="Street address *" required>
            </div>
            
            <div class="form-row">
              <input type="text" name="billing_address_2" id="billing_address_2" placeholder="Apartment, suite, unit, etc. (optional)">
            </div>
            
            <div class="form-row">
              <input type="text" name="billing_city" id="billing_city" placeholder="Town / City *" required>
            </div>
            
            <div class="form-row">
              <select name="billing_country" id="billing_country">
                <option value="">Select country / region *</option>
                <?php 
                $countries = WC()->countries->get_countries();
                foreach ($countries as $code => $name) {
                  echo '<option value="' . esc_attr($code) . '">' . esc_html($name) . '</option>';
                }
                ?>
              </select>
            </div>
            
            <div class="form-row">
              <input type="text" name="billing_postcode" id="billing_postcode" placeholder="ZIP Code *" required>
            </div>
            
            <div class="form-row">
              <input type="email" name="billing_email" id="billing_email" placeholder="Email *" required>
            </div>
            
            <div class="form-row">
              <input type="tel" name="billing_phone" id="billing_phone" placeholder="Phone number *" required>
            </div>
            
            <div class="checkbox-row">
              <input type="checkbox" name="createaccount" id="createaccount" value="1">
              <label for="createaccount">Create an account?</label>
            </div>
          </div>
          
          <!-- Right column - Shipping details (hidden by default) -->
          <div class="shipping-column" id="shipping-column" style="display: none;">
            <div class="form-row">
              <input type="text" name="shipping_first_name" id="shipping_first_name" placeholder="First name *">
            </div>
            
            <div class="form-row">
              <input type="text" name="shipping_last_name" id="shipping_last_name" placeholder="Last name *">
            </div>
            
            <div class="form-row">
              <input type="text" name="shipping_company" id="shipping_company" placeholder="Company (optional)">
            </div>
            
            <div class="form-row">
              <input type="text" name="shipping_address_1" id="shipping_address_1" placeholder="Street address *">
            </div>
            
            <div class="form-row">
              <input type="text" name="shipping_address_2" id="shipping_address_2" placeholder="Apartment, suite, unit, etc. (optional)">
            </div>
            
            <div class="form-row">
              <input type="text" name="shipping_city" id="shipping_city" placeholder="Town / City *">
            </div>
            
            <div class="form-row">
              <select name="shipping_country" id="shipping_country">
                <option value="">Select country / region *</option>
                <?php 
                foreach ($countries as $code => $name) {
                  echo '<option value="' . esc_attr($code) . '">' . esc_html($name) . '</option>';
                }
                ?>
              </select>
            </div>
            
            <div class="form-row">
              <input type="text" name="shipping_postcode" id="shipping_postcode" placeholder="ZIP Code *">
            </div>
            
            <div class="form-row">
              <textarea name="order_comments" id="order_comments" placeholder="Notes about your order, e.g., special notes for delivery." rows="4"></textarea>
            </div>
          </div>
        </div>
        
        <!-- Removed duplicate ship to different address checkbox -->
        
        <!-- Order Summary -->
        <h2 class="checkout-heading">Your Order</h2>
        
        <div class="order-summary">
          <?php if (WC()->cart->get_cart_contents_count() > 0) : ?>
            <?php foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) :
              $_product = $cart_item['data'];
              $quantity = $cart_item['quantity'];
              // Get "size" variation if present
              $size_display = '';
              if ($cart_item['variation_id'] && !empty($cart_item['variation'])) {
                foreach ($cart_item['variation'] as $attr => $val) {
                  if (stripos($attr, 'size') !== false) {
                    $size_display = $val;
                    break;
                  }
                }
              }
            ?>
              <div class="order-item">
                <div class="order-item-image">
                  <?php echo $_product->get_image([80, 80]); ?>
                </div>
                
                <div class="order-item-details">
                  <div class="order-item-name">
                    <?php echo esc_html($_product->get_name()); ?>
                    <?php if ($size_display) : ?>
                      <span style="font-size:0.8em; color:#aaa;"> - Size: <?php echo esc_html($size_display); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
                
                <div class="order-item-quantity">
                  <?php echo esc_html($quantity); ?>
                </div>
                
                <div class="order-item-price">
                  <?php echo wc_price($_product->get_price()); ?>
                </div>
                
                <div class="order-item-total">
                  <?php echo wc_price($quantity * $_product->get_price()); ?>
                </div>
              </div>
            <?php endforeach; ?>
            
            <div class="order-totals">
              <div class="order-total-row">
                <div class="order-total-label">Subtotal</div>
                <div class="order-total-value"><?php echo wc_price(WC()->cart->get_subtotal()); ?></div>
              </div>
              
              <div class="order-total-row">
                <div class="order-total-label">Shipping</div>
                <div class="order-total-value">
                  <?php 
                  $shipping_methods = WC()->shipping->get_packages();
                  
                  if (empty($shipping_methods)) {
                    echo 'Enter your address to view shipping options.';
                  } else {
                    wc_cart_totals_shipping_html();
                  }
                  ?>
                </div>
              </div>
              
              <div class="order-total-row" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #333333;">
                <div class="order-total-label" style="font-weight: bold;">Total</div>
                <div class="order-total-value" style="color: #ff0000;"><?php echo wc_price(WC()->cart->get_total()); ?></div>
              </div>
            </div>
          <?php else : ?>
            <p>Your cart is empty. Please add some products before proceeding to checkout.</p>
          <?php endif; ?>
        </div>
        
        <!-- Payment Methods -->
        <div class="payment-methods">
          <div class="payment-option">
            <input type="radio" name="payment_method" id="payment_method_stripe" value="stripe" checked>
            <label for="payment_method_stripe">Credit Card</label>
          </div>
          
          <div class="payment-icons">
            <div class="payment-icon" style="background-image: url(<?php echo esc_url(home_url('/wp-content/plugins/woocommerce-gateway-stripe/assets/images/visa.svg')); ?>); background-repeat: no-repeat; background-position: center; background-size: 80%;"></div>
            <div class="payment-icon" style="background-image: url(<?php echo esc_url(home_url('/wp-content/plugins/woocommerce-gateway-stripe/assets/images/mastercard.svg')); ?>); background-repeat: no-repeat; background-position: center; background-size: 80%;"></div>
            <div class="payment-icon" style="background-image: url(<?php echo esc_url(home_url('/wp-content/plugins/woocommerce-gateway-stripe/assets/images/amex.svg')); ?>); background-repeat: no-repeat; background-position: center; background-size: 80%;"></div>
          </div>
          
          <!-- Stripe Elements Placeholder -->
          <div id="stripe-payment-data" style="margin-top: 20px; padding: 20px; background-color: #333333;">
            <div class="form-row">
              <div id="stripe-card-element">
                <!-- Stripe Elements will be inserted here -->
              </div>
            </div>
            
            <!-- If Stripe is not initialized/visible, show fallback credit card fields -->
            <div id="stripe-fallback-form" style="display: none;">
              <div class="form-row">
                <input type="text" id="card-number" placeholder="Card Number *" style="width: 100%; margin-bottom: 10px;">
              </div>
              <div style="display: flex; gap: 15px;">
                <div class="form-row" style="flex: 1;">
                  <input type="text" id="card-expiry" placeholder="MM / YY *">
                </div>
                <div class="form-row" style="flex: 1;">
                  <input type="text" id="card-cvc" placeholder="CVC *">
                </div>
              </div>
            </div>
          </div>
          
          <button type="submit" class="place-order-button" name="woocommerce_checkout_place_order" id="place_order" value="Place order">PROCEED TO CHECKOUT</button>
          
          <?php wp_nonce_field('woocommerce-process_checkout', 'woocommerce-process-checkout-nonce'); ?>
        </div>
      </form>
    </div>
  </div>
  <!-- end .desktop-layout -->

  <!-- MOBILE LAYOUT (same structure but with mobile-friendly styling) -->
  <div class="mobile-layout">
    <!-- Mobile layout will be very similar to desktop but with adjusted styling for smaller screens -->
    <h2 class="checkout-heading">Checkout</h2>
    
    <!-- Returning customer info box -->
    <div class="checkout-info-box">
      <p>Returning customer? <span class="checkout-link" id="login-trigger-mobile">Click here to login</span></p>
    </div>
    
    <!-- Login form (hidden by default) -->
    <div id="login-form-mobile" style="display: none; margin-bottom: 15px;">
      <?php 
      // Display the WooCommerce login form
      woocommerce_login_form(array(
        'message' => '',
        'redirect' => wc_get_checkout_url(),
        'hidden' => false,
      )); 
      ?>
    </div>
    
    <!-- Coupon info box -->
    <div class="checkout-info-box">
      <p>Have a coupon? <span class="checkout-link" id="coupon-trigger-mobile">Click here to enter your code</span></p>
    </div>
    
    <!-- Coupon form (hidden by default) -->
    <div id="coupon-form-mobile" class="coupon-form">
      <form method="post" action="<?php echo esc_url(wc_get_cart_url()); ?>">
        <input type="text" name="coupon_code" placeholder="Coupon code">
        <button type="submit" class="button" name="apply_coupon" value="Apply coupon">Apply</button>
        <?php wp_nonce_field('woocommerce-cart', 'woocommerce-cart-nonce'); ?>
      </form>
    </div>
    
    <!-- Rest of the mobile checkout form follows the same structure as desktop -->
    <!-- Form will be adjusted for mobile view through CSS -->
  </div>
  <!-- end .mobile-layout -->

</main>

<!-- Checkout JS -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  // Toggle login form
  const loginTrigger = document.getElementById('login-trigger');
  const loginForm = document.getElementById('login-form');
  
  if (loginTrigger && loginForm) {
    loginTrigger.addEventListener('click', function() {
      loginForm.style.display = loginForm.style.display === 'none' ? 'block' : 'none';
    });
  }
  
  // Toggle coupon form
  const couponTrigger = document.getElementById('coupon-trigger');
  const couponForm = document.getElementById('coupon-form');
  
  if (couponTrigger && couponForm) {
    couponTrigger.addEventListener('click', function() {
      couponForm.style.display = couponForm.style.display === 'none' ? 'block' : 'none';
    });
  }
  
  // Toggle shipping address
  const shipToDifferentAddress = document.getElementById('ship_to_different_address');
  const shippingColumn = document.getElementById('shipping-column');
  
  if (shipToDifferentAddress && shippingColumn) {
    shipToDifferentAddress.addEventListener('change', function() {
      shippingColumn.style.display = this.checked ? 'block' : 'none';
    });
  }
  
  // Same for mobile
  const loginTriggerMobile = document.getElementById('login-trigger-mobile');
  const loginFormMobile = document.getElementById('login-form-mobile');
  
  if (loginTriggerMobile && loginFormMobile) {
    loginTriggerMobile.addEventListener('click', function() {
      loginFormMobile.style.display = loginFormMobile.style.display === 'none' ? 'block' : 'none';
    });
  }
  
  const couponTriggerMobile = document.getElementById('coupon-trigger-mobile');
  const couponFormMobile = document.getElementById('coupon-form-mobile');
  
  if (couponTriggerMobile && couponFormMobile) {
    couponTriggerMobile.addEventListener('click', function() {
      couponFormMobile.style.display = couponFormMobile.style.display === 'none' ? 'block' : 'none';
    });
  }
  
  // Initialize Stripe Elements (if Stripe is available)
  const stripeFallbackForm = document.getElementById('stripe-fallback-form');
  
  // Function to load Stripe
  function initStripe() {
    if (typeof Stripe !== 'undefined') {
      try {
        const stripeKey = '<?php echo esc_js(get_option('woocommerce_stripe_settings')['publishable_key'] ?? ''); ?>';
        if (!stripeKey) {
          // If no Stripe key is found, show fallback form
          if (stripeFallbackForm) stripeFallbackForm.style.display = 'block';
          return;
        }
        
        const stripe = Stripe(stripeKey);
        const elements = stripe.elements();
        
        const style = {
          base: {
            color: '#ffffff',
            fontFamily: '"Source Sans Pro", sans-serif',
            fontSmoothing: 'antialiased',
            fontSize: '16px',
            '::placeholder': {
              color: '#aaaaaa'
            }
          },
          invalid: {
            color: '#ff0000',
            iconColor: '#ff0000'
          }
        };
        
        const cardElement = elements.create('card', { style: style });
        
        // Mount the card Element
        if (document.getElementById('stripe-card-element')) {
          cardElement.mount('#stripe-card-element');
          console.log('Stripe card element mounted successfully');
        } else {
          console.error('Stripe card element container not found');
          if (stripeFallbackForm) stripeFallbackForm.style.display = 'block';
        }
      } catch (error) {
        console.error('Error initializing Stripe:', error);
        if (stripeFallbackForm) stripeFallbackForm.style.display = 'block';
      }
    } else {
      // Stripe is not available, show fallback form
      console.warn('Stripe.js not found. Showing fallback payment form.');
      if (stripeFallbackForm) stripeFallbackForm.style.display = 'block';
      
      // Load Stripe.js dynamically
      const script = document.createElement('script');
      script.src = 'https://js.stripe.com/v3/';
      script.onload = function() {
        console.log('Stripe.js loaded dynamically');
        // Try initializing again after script loads
        setTimeout(initStripe, 500);
      };
      document.head.appendChild(script);
    }
  }
  
  // Initialize Stripe
  initStripe();
});
</script>

<?php
get_footer();